// Define array to store information about registered services
let services = [];

// Constructor for Service objects
function Service(description, price) {
    this.description = description;
    this.price = price;
}

// Function to register a new service
function registerService(event) {
    event.preventDefault(); // Prevent form submission

    // Get values from the form
    const description = $('#service-description').val();
    const price = parseFloat($('#service-price').val());

    // Validate inputs
    if (!description || isNaN(price) || price <= 0) {
        // Show error message using jQuery
        $('#services-form').append('<p class="text-danger mt-3">Please enter valid description and price!</p>');
        return;
    }

    // Create a new service object
    const newService = new Service(description, price);

    // Add the new service to the services array
    services.push(newService);

    // Show success message using jQuery
    $('#services-form').append('<p class="text-success mt-3">Service registered successfully!</p>');

    // Reset the form
    event.target.reset();
}

// Add event listener to services form
$('#services-form').submit(registerService);
