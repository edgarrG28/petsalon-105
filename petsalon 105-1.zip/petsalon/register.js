// Define arrays to store information about registered pets
let pets = [];
let dogCount = 0;
let catCount = 0;
let otherCount = 0;

// Function to display the registered pets count and type counts
function displayPetsCount() {
    const totalPetsCount = pets.length;
    const petsCountElement = document.getElementById("pets-count");
    const dogCountElement = document.getElementById("dog-count");
    const catCountElement = document.getElementById("cat-count");
    const otherCountElement = document.getElementById("other-count");

    if (petsCountElement) {
        petsCountElement.textContent = totalPetsCount;
    }

    if (dogCountElement) {
        dogCountElement.textContent = dogCount;
    }

    if (catCountElement) {
        catCountElement.textContent = catCount;
    }

    if (otherCountElement) {
        otherCountElement.textContent = otherCount;
    }
}

// Function to display pet cards
function displayPetCards() {
    const petCardsContainer = document.getElementById("pet-cards");
    if (petCardsContainer) {
        petCardsContainer.innerHTML = ''; // Clear previous content

        pets.forEach((pet, index) => {
            const card = document.createElement("div");
            card.className = "col-md-4 mb-3";

            card.innerHTML = `
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${pet.name}</h5>
                        <p class="card-text">Breed: ${pet.breed}</p>
                        <p class="card-text">Type: ${pet.type}</p>
                        <p class="card-text">Gender: ${pet.gender}</p>
                        <p class="card-text">Age: ${pet.age}</p>
                        <p class="card-text">Service: ${pet.service}</p>
                        <p class="card-text">Color: ${pet.color}</p>
                        <button class="btn btn-danger delete-button" data-index="${index}">Delete</button>
                    </div>
                </div>
            `;

            petCardsContainer.appendChild(card);
        });

        // Add event listeners to delete buttons
        const deleteButtons = document.querySelectorAll(".delete-button");
        deleteButtons.forEach(button => {
            button.addEventListener("click", function() {
                const index = parseInt(button.getAttribute("data-index"));
                deletePet(index);
            });
        });
    }
}

// Function to register a new pet
function registerPet(event) {
    event.preventDefault(); // Prevent form submission

    // Get values from the form
    const name = document.getElementById("pet-name").value;
    const breed = document.getElementById("pet-breed").value;
    const type = document.getElementById("pet-type").value;
    const gender = document.getElementById("pet-gender").value;
    const age = parseInt(document.getElementById("pet-age").value);
    const service = document.getElementById("pet-service").value;
    const color = document.getElementById("pet-color").value;

    // Create a new pet object
    const newPet = {
        name: name,
        age: age,
        gender: gender,
        service: service,
        breed: breed,
        type: type,
        color: color // Add color attribute
    };

    // Add the new pet to the pets array
    pets.push(newPet);

    // Update type count based on the pet type
    if (type === "Dog") {
        dogCount++;
    } else if (type === "Cat") {
        catCount++;
    } else {
        otherCount++;
    }

    // Update display of registered pets count and pet cards
    displayPetsCount();
    displayPetCards();

    // Show confirmation message and "Click here to pay" button using jQuery
    $('#registration-form').append('<p class="text-success mt-3">Thank you for registering your pet!</p>');

    const payButton = $('<button class="btn btn-primary mt-2">Click here to pay</button>');
    payButton.click(function() {
        window.location.href = "payment.html"; // Redirect to payment page
    });
    $('#registration-form').append(payButton);

    // Reset the form
    event.target.reset();
}

// Add event listener to registration form
$('#registration-form').submit(registerPet);

// Initial display of registered pets count and pet cards
displayPetsCount();
displayPetCards();
