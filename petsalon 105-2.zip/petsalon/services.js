// Function to register a new service
function registerService(event) {
    event.preventDefault(); // Prevent form submission

    // Get values from the form
    const description = $('#service-description').val();
    const price = parseFloat($('#service-price').val());

    // Validate inputs
    if (!description || isNaN(price) || price <= 0) {
        // Show error message using jQuery
        $('#services-form').append('<p class="text-danger mt-3">Please enter valid description and price!</p>');
        return;
    }

    // Create a new service object
    const newService = {
        description: description,
        price: price
    };

    // Retrieve existing services from local storage or initialize as empty array
    let services = JSON.parse(localStorage.getItem('services')) || [];

    // Add the new service to the services array
    services.push(newService);

    // Save the updated services array to local storage
    localStorage.setItem('services', JSON.stringify(services));

    // Show success message using jQuery
    $('#services-form').append('<p class="text-success mt-3">Service registered successfully!</p>');

    // Reset the form
    $('#service-description').val('');
    $('#service-price').val('');
}

// Add event listener to services form
$('#services-form').submit(registerService);
