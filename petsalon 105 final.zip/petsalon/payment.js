// Function to handle payment form submission
const submitPayment = (event) => {
    event.preventDefault(); // Prevent form submission

    // Validate card details
    const cardName = $('#card-name').val();
    const cardNumber = $('#card-number').val();
    const cardExpiration = $('#card-expiration').val();
    const cardCVV = $('#card-cvv').val();
    const cardZip = $('#card-zip').val();

    if (!cardName || !cardNumber || !cardExpiration || !cardCVV || !cardZip) {
        // Show error message using jQuery
        $('#payment-message').html('<p class="text-danger">Please fill in all the required fields.</p>').show();
        return;
    }

    // Show success message using jQuery
    $('#payment-message').html('<p class="text-success">Your payment has been processed.</p>').show();

    // Optionally, you can redirect to a thank you page or perform other actions here

    // Reset the form
    event.target.reset();
};

// Add event listener to payment form
$('#payment-form').submit(submitPayment);
